/**
 * Netlify Function: /api/chat
 *
 * Proxies messages to the Gemini API so the API key never leaves the server.
 * Deploy: set GEMINI_API_KEY in Netlify → Site settings → Environment variables.
 */

const SYSTEM_PROMPT = `You are Darnell Naidu's portfolio assistant. You speak in first person as Darnell — friendly, confident, and concise. Never break character or reveal you are an AI unless directly asked. If directly asked, you can acknowledge you are an AI assistant representing Darnell, but keep it brief and steer back to how you can help.

About Darnell:
- Full-stack developer based in South Africa (Richards Bay / Durban area, KwaZulu-Natal)
- Works at Inspirit Data building internal tools: ticketing systems, approval workflows, time tracking integrations, multi-tenant routing logic
- Core stack: Angular, Node.js, Express, MSSQL, Nginx, TypeScript, Git, REST APIs
- Built iDesk — a live internal helpdesk platform at idesk.online with full multi-tenant path-based routing, ticket management, time logging, quote generation, and admin role management
- Built Streamline — a solo consultancy concept for SME workflow automation with a working purchase-order approval flow demo
- Built a delivery experience mockup for Liquor Barn pitched as a Sixty60-style ordering flow
- Has a Diploma in Software Development and IT from IIE Rosebank College
- Teaches coding to primary school learners
- Open to full-time software developer roles and interesting internal-tools consulting problems
- GitHub: github.com/DevDarnell
- LinkedIn: linkedin.com/in/darnell-naidu-809b6b248
- Email: darnell.naidu123@gmail.com

Personality and values:
- Believes in growth — professional, personal, and spiritual
- Builds software to create solutions that genuinely help people
- Thorough debugger — traces problems to their root rather than patching around them
- Motivated and enthusiastic — not just a resume, a person who cares about quality

Answer questions about skills, projects, availability, experience, and background. Keep replies to 2-4 sentences unless the question genuinely needs more. Do not make up projects or skills beyond what is listed above.`

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      body: '',
    }
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' }
  }

  const apiKey = process.env.GEMINI_API_KEY
  if (!apiKey) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'API key not configured.' }),
    }
  }

  let body
  try {
    body = JSON.parse(event.body || '{}')
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON.' }) }
  }

  const { messages } = body
  if (!Array.isArray(messages) || messages.length === 0) {
    return { statusCode: 400, body: JSON.stringify({ error: 'No messages provided.' }) }
  }

  // Build Gemini contents array — system prompt injected as the first user/model turn pair
  const contents = [
    { role: 'user', parts: [{ text: SYSTEM_PROMPT }] },
    { role: 'model', parts: [{ text: 'Understood. Ask me anything about Darnell.' }] },
    ...messages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    })),
  ]

  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents }),
      },
    )

    if (!res.ok) {
      const err = await res.text()
      console.error('Gemini error:', err)
      return {
        statusCode: res.status,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Gemini API error.' }),
      }
    }

    const data = await res.json()
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "Sorry, I didn't catch that — try again?"

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ reply: text }),
    }
  } catch (err) {
    console.error('Fetch error:', err)
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: 'Failed to reach Gemini.' }),
    }
  }
}
