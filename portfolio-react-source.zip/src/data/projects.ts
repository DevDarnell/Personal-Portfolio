import type { Project } from '@/components/ProjectCard'

export const PROJECTS: Project[] = [
  {
    id: 'TCK-014 · MULTI-TENANT',
    title: 'iDesk — Inspirit Ticketing System',
    description:
      'The internal helpdesk platform Inspirit runs support on. Routes tickets across product buckets, manages admin roles, logs time, and generates quotes — live at idesk.online.',
    caseNote:
      'Rebuilt tenant routing from subdomain- to path-based across 9 files; traced a tenant-isolation bug to one interceptor that had never been saved to disk.',
    tags: ['Angular', 'Node/Express', 'MSSQL', 'Nginx'],
    filterTags: ['angular', 'node', 'mssql', 'nginx', 'multitenant'],
  },
  {
    id: 'TCK-027 · WORKFLOW',
    title: 'Streamline — Workflow Automation',
    description:
      'A solo consultancy concept for SME approval automation. Built a working demo of a purchase-order approval flow, using motion to make each step\u2019s status legible at a glance.',
    tags: ['Angular', 'Approval workflows', 'Motion design'],
    filterTags: ['angular'],
  },
  {
    id: 'TCK-033 · PROPOSAL',
    title: 'Liquor Barn — Delivery Concept',
    description:
      'A clickable mockup for an on-demand liquor delivery experience, built to pitch the client on a Sixty60-style ordering flow.',
    tags: ['UX mockup', 'Client proposal'],
    filterTags: [],
  },
]
